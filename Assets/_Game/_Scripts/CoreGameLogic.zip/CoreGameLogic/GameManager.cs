using System;
using Unity.Netcode;
using UnityEngine;
using TMPro;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using Unity.VisualScripting;


public class GameManager : NetworkBehaviour
{


    public enum GameState
    {
        Loading,
        Start,
        Play,
        End
    }
    [Header("Configuration Settings")]
    [Space(10)]

    [SerializeField]
    private GameSettings _gameSettings;

    [Header("Player Elements")]
    [Space(10)]

    [SerializeField]
    private Transform[] _spawnPoints;


    [Header("UI Elements")]
    [Space(10)]
    [SerializeField]
    public UiManager UIManager;

    [Header("Testing Elements")]
    [Space(10)]
    [SerializeField]
    private bool _isTesting;

    [SerializeField]
    private TextMeshProUGUI _testModeText;

    [HideInInspector]
    public string _winnerName;
    
    
    [Header("Multiplayer Variables")]
    [SerializeField]private NetworkVariable<float> _timeleftinGame = new(writePerm: NetworkVariableWritePermission.Server);
    [SerializeField]private List<PlayerScoreBoard> player_holder = new List<PlayerScoreBoard>();
    [SerializeField]private NetworkVariable<GameState> _gameState = new(writePerm: NetworkVariableWritePermission.Server);
    [SerializeField] private NetworkList<PlayerData> _playerdata = new NetworkList<PlayerData>();
    [SerializeField] private NetworkVariable<PlayerData> _playerwinner = new(writePerm: NetworkVariableWritePermission.Server);


    //gameclientonlyvariable
    bool startedclient;

  
    


    //begin
    private void Awake()
    {
        UIManager._gameManager = this;
        EventDelegates();

    }

    void EventDelegates()
    {
        //EventManager.OnGameStart += OnGameStart;
        // EventManager.OnGameEnd += OnGameEnd;
        // EventManager.OnGameFull += OnGameFull;
        // EventManager.OnPlayerLeft += OnPlayerScored;
        // EventManager.OnPlayerJoined += OnPlayerScored;
    }



    void Start()
    {
        if (!_isTesting)
        {
            _testModeText?.gameObject.SetActive(false);

            //  StartCoroutine(VeryFirstGameLoop());
        }
        else
        {
            ResetGameState();
            _testModeText.gameObject.SetActive(true);
            // _animatorCamera.Play("_gameidle");


        }
    }



    public IEnumerator VeryFirstGameLoop()
    {
        if (IsServer)
        {
            _gameState.Value = GameState.Loading;
        }

        // while (!_animatorCamera.GetCurrentAnimatorStateInfo(0).IsName("_gameidle"))
        // {
        //     yield return null;
        // }
        yield return new WaitForSeconds(0.1f);
        ResetGameState();

    }

    // Update is called once per frame
    void Update()
    {
        if (IsServer)
        {
            GameHeartbeat();
        }
        else
        {
            GameClientUpdate();
        }

        GameUIHandling();

    }

    void ResetGameState()
    {
        // PlayerSetups();
        UIManager._resetButton?.SetActive(false);

        ///serverlogic
        if (IsServer)
        {
            _gameState.Value = GameState.Start;
        }

        if (IsServer)
        {
            _timeleftinGame.Value = _gameSettings.gameTimer;

        }

        UIManager._AnnoucePanel.SetActive(true);
        UIManager._overtimeText.gameObject.SetActive(false);
        UIManager._annoucerText.text = "Get Ready!";
        UIManager._HUDPanel.SetActive(false);
        StartCoroutine(StartGame());

    }

    IEnumerator StartGame()
    {
        UIManager._CountdownPanel.SetActive(true);
        UIManager._countdownText.text = _gameSettings.gameStartDelay.ToString("0");
        var timeleft = 0f;
        for (timeleft = _gameSettings.gameStartDelay; timeleft > 0; timeleft -= Time.deltaTime)
        {
            UIManager._CountdownPanel.SetActive(true);
            UIManager._countdownText.text = timeleft.ToString("0");
            yield return null;
        }

        UIManager._CountdownPanel.SetActive(false);
        ///serverlogic
        if (IsServer)
        {
            _gameState.Value = GameState.Play;
        }

        EventManager.StartGame();
    }

    IEnumerator EndGame()
    {
        //  _coinDropController.CancelHeartbeat();
        ///serverlogic
        if (IsServer)
        {
            _gameState.Value = GameState.End;
            var scorebaord =  checkWinner();
            ProcessEndGame(scorebaord);
            
        }

        UIManager._resetButton.SetActive(true);
        EventManager.EndGame();
        yield return new WaitForSeconds(_gameSettings.gameEndDelay);
    }

    PlayerScoreBoard checkWinner()
    {
        var winner = player_holder[1];
        
        //win condition here
        // foreach (var player in player_holder)
        // {
        //     if (player.playerData.Playerscore > winner.playerData.Playerscore)
        //     {
        //         winner = player;
        //     }
        // }

        _winnerName = winner.playerName;
        UIManager._annoucerText.text = winner.playerName + " Wins!";
        
        return winner;


    }

    bool checkNoDraws()
    {
        List<PlayerScoreBoard> potentialwinners = new List<PlayerScoreBoard>();
        var winner = player_holder[0];
        bool draw = false;
        foreach (var player in player_holder)
        {
            //check list to see if player is drawing
            if (player.playerData.Playerscore == winner.playerData.Playerscore)
            {
                //if player is drawing add to list
                potentialwinners.Add(player);
            }
            else if (player.playerData.Playerscore > winner.playerData.Playerscore)
            {

                //if player is not drawing and has a higher score than the current winner and clear the list
                winner = player;
                potentialwinners.Clear();
                potentialwinners.Add(player);
            }
        }

        if (potentialwinners.Count > 1)
        {
            IncreaseTimeDueToDraw();
            return false;
        }


        return true;
    }

    void IncreaseTimeDueToDraw()
    {
        if (IsServer)
        {
            _timeleftinGame.Value += _gameSettings.gameOvertime;
        }

        StartCoroutine(UIManager.OvertimeText(_gameSettings.gameOvertime));
    }

    void GameHeartbeat()
    {

        if (_gameState.Value != GameState.Play)
        {
            return;
        }

        if (IsServer)
        {
            _timeleftinGame.Value -= Time.unscaledDeltaTime;
        }




        //uncomment for draw
        // if(_timeleftinGame <= 5)
        // {
        //     checkNoDraws();
        // }

        // if(_timeleftinGame <= 0 && checkNoDraws())
        // {
        //     StartCoroutine(EndGame());
        // }
        if (_timeleftinGame.Value <= 0)
        {
            StartCoroutine(EndGame());
        }
    }


    #region GameUI

    void GameUIHandling()
    {
        UIManager.HandleUi(CheckUIForPlayers, _gameState.Value, _timeleftinGame.Value);
    }

    // IEnumerator OvertimeText()
    // {
    //     UIManager._overtimeText.gameObject.SetActive(true);
    //     UIManager._overtimeText.text = "Overtime!" + _gameSettings.gameOvertime.ToString();
    //     yield return new WaitForSeconds(3f);
    //     UIManager._overtimeText.gameObject.SetActive(false);
    //
    // }

    
  


    #endregion




    #region PlayerSetup

    public delegate void onScoreChanged();

    public onScoreChanged OnScoreChanged;
    

    #endregion


    #region CleanUp

   
    
    private void LastGameCleanUpCheck()
    {
        if (player_holder != null)
        {
            ClearPlayers();
        }
    }

    void ClearPlayers()
    {
        for (int i = 0; i < player_holder.Count; i++)
        {
            Destroy(player_holder[i].playerScoreUI.gameObject);
            Destroy(player_holder[i].playerObject.gameObject);
        }
    }

    #endregion


    #region Multiplayer only
    
    public void LastGameCleanUpCheckMulti()
    {
        if (player_holder != null)
        {
            foreach (var VARIABLE in player_holder)
            {
                VARIABLE.Clear();
            }
        }
        
        
        player_holder.Clear();

        if (IsServer)
        {
            _playerdata.Clear();
        }
    }
    void GameClientUpdate()
    {
        if (_gameState.Value == GameState.Start && !startedclient)
        {
            startedclient = true;
            ResetGameState();
            
        }
    }
    
    //adds player data to the player holder for the sever
    public void AddPlayerData(NetworkClient client, FixedString128Bytes systemId)
    {
        var playerd =  new PlayerData(client.ClientId, 0, systemId, true);
      _playerdata.Add(playerd);
    }

    public void ProcessEndGame(PlayerScoreBoard winner)
    {
        if (!IsServer)
        {
            return;
        }

        _playerwinner.Value = winner.playerData;
        List<RPCManager> v = new List<RPCManager>();
        foreach (var VARIABLE in FindObjectsOfType<RPCManager>())
        {
            v.Add(VARIABLE);
            VARIABLE.WinnerAnimState(winner.playerData.PlayerID);
        }
        
        
        EndGameUi();
        RPCWinnerAnnoucedClientRPC();

    }
    
    public void ProcessEndGameClientSide()
    {
        if (!IsServer)
        {

            Debug.Log("winner is " + _playerwinner.Value.PlayerID);
            
            EndGameUi();
        }


    }

    void EndGameUi()
    {
       

        for (int i = 0; i < _playerdata.Count; i++)
        {
            if(_playerdata[i].PlayerID == _playerwinner.Value.PlayerID)
            {
                player_holder[i].playerScoreUI.Winner();
            }
        }
    }
   
    

    public bool HasGameStarted()
    {
        if (_gameState.Value == GameState.Play)
        {
            return true;
        }

        return false;
    }
    
    #region UIMultiplayer
    bool recheck = false;

    void CheckUIForPlayers()
    {
        if(_playerdata == null){return;}
//        Debug.Log("Checking UI for players" + _playerdata.Count + " || " + player_holder.Count);
        if(player_holder.Count != _playerdata.Count)
        {
            foreach (var VARIABLE in player_holder)
            {
                VARIABLE.Clear();
            }
            player_holder.Clear();
            player_holder = new List<PlayerScoreBoard>();
            for (int i = 0; i < _playerdata.Count; i++)
            {

                var v = CreatePlayerScoreboard(_playerdata[i]);
                player_holder.Add(v);
            }

        }else if(recheck)
        {
            recheck = false;
            
            foreach (var VARIABLE in player_holder)
            {
                VARIABLE.Clear();
            }
            
            player_holder.Clear();
            player_holder = new List<PlayerScoreBoard>();
            for (int i = 0; i < _playerdata.Count; i++)
            {
                var v = CreatePlayerScoreboard(_playerdata[i]);
                player_holder.Add(v);
            }
           
        }

    }
    private void checkUIOnReconnect(ulong obj)
    {
        recheck = true;
    }
    void FuzzyCheckForPlayerStillConnected(ulong clientid)
    {
        for (int i = 0; i < _playerdata.Count; i++)
        {
            if(_playerdata[i].PlayerID == clientid)
            {
                bool found = false;
                player_holder[i].disconnect();
                
                var v = new PlayerData(_playerdata[i].PlayerID, _playerdata[i].Playerscore, _playerdata[i].systemID, false);
                _playerdata[i] = v;
                return;
            }
            
        }
    }
    PlayerScoreBoard CreatePlayerScoreboard(PlayerData playerData)
    {
        
        if(playerData.Playerconnected)
        {
            var v = new PlayerScoreBoard();
            v.playerData = playerData;
            v.playerScoreUI = Instantiate(_gameSettings.playerScoreUI, UIManager._playerScoreUIParent);
            v.playerScoreUI.Init(v);
            return v;
        }else
        {
            var v = new PlayerScoreBoard();
            v.playerData = playerData;
            Debug.Log("Player not connected");

            return v;
        }
       
    }
    
    
    
    
    #endregion
    
    
    
    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();
        NetworkManager.Singleton.OnClientDisconnectCallback += FuzzyCheckForPlayerStillConnected;
        NetworkManager.Singleton.OnClientConnectedCallback += checkUIOnReconnect;
        
        
        if(IsServer)
        {
            GetComponent<NetManage>().OnAllPlayersConnected += BeginGame;
           // NetManage.OnAllPlayersConnected += BeginGame;
        }


    }

    void BeginGame( object sender, EventArgs e)
    {
        
        
        
        StartCoroutine(VeryFirstGameLoop());
    }
    
    public override void OnNetworkDespawn()
    {
        base.OnNetworkDespawn();
        NetworkManager.Singleton.OnClientDisconnectCallback -= FuzzyCheckForPlayerStillConnected;
        NetworkManager.Singleton.OnClientConnectedCallback -= checkUIOnReconnect;
        

        
        if(IsServer)
        {
            GetComponent<NetManage>().OnAllPlayersConnected -= BeginGame;
           // NetManage.OnAllPlayersConnected -= BeginGame;
        }
        //NetManage.OnAllPlayersConnected -= BeginGame;

    }
    

    [ClientRpc]
    void RPCWinnerAnnoucedClientRPC()
    {
        ProcessEndGameClientSide();
    }
    
    
    


}



#endregion



