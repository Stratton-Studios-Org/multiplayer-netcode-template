using System;
using Unity.Collections;

public partial class NetManage
{
    [Serializable]
    public class ISessionPlayerData
    {
        public bool IsConnected;
        public int playerID;

        public ulong ClientID;

        public FixedString128Bytes systemID;
        
    }
}