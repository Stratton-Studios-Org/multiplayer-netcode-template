using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Netcode;
using UnityEngine;
using System;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;
public partial class NetManage : NetworkBehaviour
{
    NetworkManager networkManager;
    private int playerIDs;
    
    
    public List<ISessionPlayerData> playerList = new List<ISessionPlayerData>();
    
    public  EventHandler OnAllPlayersConnected;

    public override void OnNetworkSpawn() {
        
        base.OnNetworkSpawn();
        Debug.Log("Spawned");
        networkManager = NetworkManager.Singleton;
        networkManager.OnClientConnectedCallback += OnClientConnected;
        networkManager.OnClientDisconnectCallback += OnClientDisconnected;
        Debug.Log(networkManager.IsServer);
        
        if (networkManager.IsHost) {
            playerIDs = 0;
            AddPlayerData(networkManager.LocalClientId);
            playerList[0].systemID = networkManager.LocalClient.PlayerObject.GetComponent<SystemGuid>().GetGuid();
            StartCoroutine(SetupPlayerData(networkManager.LocalClientId, SetupPlayerDataCallback));

        }

        if (IsServer)
        {
            GameManager g = FindObjectOfType<GameManager>();
            g.LastGameCleanUpCheckMulti();
        }
        
    }

    public override void OnNetworkDespawn()
    {
        base.OnNetworkDespawn();
        if (networkManager != null)
        {
            networkManager.OnClientConnectedCallback -= OnClientConnected;
            networkManager.OnClientDisconnectCallback -= OnClientDisconnected;
        }
        
        playerList.Clear();
        Debug.Log("Despawned");
    }
    void OnClientConnected(ulong clientId) {
         if(!IsServer){return;}
         Debug.Log("Client connected" + clientId);

        var oldplayerid = playerList.Find(x => x.ClientID == clientId);

        if (oldplayerid != null)
        {
            oldplayerid.IsConnected = true;
            return;
        }else
        {
            playerIDs++;
            AddPlayerData(clientId);
            //  SpawnPlayerServerRpc(clientId);
        }


        StartCoroutine(SetupPlayerData(clientId, SetupPlayerDataCallback));

     }

     void OnClientDisconnected(ulong clientId) {
         if(!IsServer){return;}

         Debug.Log("Client disconnected");

         foreach (var VARIABLE in playerList)
         {
             var sessionPlayerData = VARIABLE;
             if(sessionPlayerData.ClientID == clientId)
             {
                    sessionPlayerData.IsConnected = false;
                 
              
             }
         }

            networkManager.ConnectedClients.TryGetValue(clientId, out var networkedClient);
            networkedClient.PlayerObject.GetComponent<NetworkObject>().Despawn(true);
        

     }
     
     public void SetupPlayerDataCallback(bool isDone){
         if(isDone)
            {
                CheckAllPlayers();
            }
     }

     IEnumerator SetupPlayerData(ulong clientId, Action<bool> callback)
     {
         yield return new WaitForSeconds(0.1f);
         GameManager g = FindObjectOfType<GameManager>();
         networkManager.ConnectedClients.TryGetValue(clientId, out var networkedClient);
        FixedString128Bytes guid = networkedClient.PlayerObject.GetComponent<SystemGuid>().GetGuid();
        playerList.Find(x => x.ClientID == clientId).systemID = guid;
        g.AddPlayerData(networkedClient, guid );
         callback(true);
         
     }

     void CheckAllPlayers()
     {
         if (!IsServer)
         {
             return;
         }
         var playersinlobby = networkManager.ConnectedClientsList.Count;
         if(playersinlobby <= 1)
         {
             Debug.Log("No players in lobby");
             return;
         }
         else
         {
             Debug.Log("Players in lobby: " + playersinlobby);
         }
        
         foreach (var VARIABLE in playerList)
         {
             if(VARIABLE.IsConnected == false)
             {
                 Debug.Log("Not all are created players created: ");

                 break;
             }
         }
         OnAllPlayersConnected?.Invoke(this, EventArgs.Empty);
     }


     #region Helper Methods
     
     private void AddPlayerData(ulong clientId)
     {
         playerList.Add(new ISessionPlayerData() { IsConnected = true, playerID = playerIDs, ClientID = clientId });
     }
     
     private void RemovePlayerData(ulong clientId)
     {
         ISessionPlayerData playerData = playerList.Find(x => x.ClientID == clientId);
         playerList.Remove(playerData);
     }


     public ISessionPlayerData GetPlayerData(ulong clientId)
        {
            foreach (var VARIABLE in playerList)
            {
                var sessionPlayerData = VARIABLE;
                if(sessionPlayerData.ClientID == clientId)
                {
                    return sessionPlayerData;
                }
            }
    
            return null;
        }
        
        public ISessionPlayerData GetPlayerData(FixedString128Bytes guid)
        {
            foreach (var VARIABLE in playerList)
            {
                var sessionPlayerData = VARIABLE;
                if(sessionPlayerData.systemID == guid)
                {
                    return sessionPlayerData;
                }
            }
    
            return null;
        }
        
        public ISessionPlayerData GetPlayerData(int playerID)
        {
            foreach (var VARIABLE in playerList)
            {
                var sessionPlayerData = VARIABLE;
                if(sessionPlayerData.playerID == playerID)
                {
                    return sessionPlayerData;
                }
            }
    
            return null;
        }
        
        public ISessionPlayerData GetPlayerData(NetworkObject networkObject)
        {
            foreach (var VARIABLE in playerList)
            {
                var sessionPlayerData = VARIABLE;
                if(sessionPlayerData.ClientID == networkObject.OwnerClientId)
                {
                    return sessionPlayerData;
                }
            }
    
            return null;
        }
        
       

     #endregion
     
     
     
     
}
